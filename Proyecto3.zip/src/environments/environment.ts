// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    projectId: 'te-acompano-512a2',
    appId: '1:115825054270:web:dbf28a9f72db8d9c85b76f',
    storageBucket: 'te-acompano-512a2.firebasestorage.app',
    apiKey: 'AIzaSyCZNh8nUTrCcPjyfYbnTRH170rQFtQ9eDQ',
    authDomain: 'te-acompano-512a2.firebaseapp.com',
    messagingSenderId: '115825054270',
    measurementId: 'G-HHDE3RW503'
  }
};


/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
