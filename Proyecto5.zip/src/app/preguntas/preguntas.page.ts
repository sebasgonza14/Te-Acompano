import { Component, OnInit } from '@angular/core';
import { Firestore, collection, addDoc, query, orderBy, onSnapshot, doc, getDoc } from '@angular/fire/firestore';
import { Auth } from '@angular/fire/auth';

@Component({
  selector: 'app-preguntas',
  templateUrl: './preguntas.page.html',
  styleUrls: ['./preguntas.page.scss'],
})
export class PreguntasPage implements OnInit {
  messages: Array<{ user: string; text: string }> = [];
  newMessage: string = '';
  currentUser: { nombre: string; apellido: string } | null = null; // Datos del usuario actual

  constructor(private firestore: Firestore, private auth: Auth) {}

  async ngOnInit() {
    await this.loadCurrentUser(); // Cargar los datos del usuario actual
    this.loadMessages(); // Cargar mensajes en tiempo real
  }

  // Obtener los datos del usuario actual desde Firebase
  async loadCurrentUser() {
    const user = this.auth.currentUser;
    if (user) {
      const userDoc = doc(this.firestore, 'users', user.uid); // Asume que el UID del usuario es la clave del documento
      const userSnapshot = await getDoc(userDoc);
      if (userSnapshot.exists()) {
        this.currentUser = userSnapshot.data() as { nombre: string; apellido: string };
      }
    }
  }

  // Cargar mensajes desde Firebase
  loadMessages() {
    const messagesRef = collection(this.firestore, 'preguntas-frecuentes');
    const q = query(messagesRef, orderBy('timestamp', 'asc'));
    onSnapshot(q, (snapshot) => {
      this.messages = snapshot.docs.map((doc) => doc.data() as { user: string; text: string });
    });
  }

  // Enviar un mensaje
  async sendMessage() {
    if (this.newMessage.trim() !== '' && this.currentUser) {
      const messagesRef = collection(this.firestore, 'preguntas-frecuentes');
      await addDoc(messagesRef, {
        user: `${this.currentUser.nombre} ${this.currentUser.apellido}`, // Usar el nombre del perfil
        text: this.newMessage.trim(),
        timestamp: new Date(),
      });

      this.newMessage = ''; // Limpiar el campo de entrada
    } else {
      alert('El mensaje no puede estar vacío o el usuario no está autenticado.');
    }
  }
}
